// api/admin-action.js
// Point d'entrée unique pour toutes les écritures admin qui étaient avant
// faites directement depuis le navigateur avec la clé Supabase publique
// (anon) via des policies RLS "ALL / true" — donc utilisables par
// n'importe qui, pas seulement l'admin. Cette route vérifie le jeton admin
// signé (le même que pour la connexion admin) puis utilise la clé service
// role côté serveur, qui n'est jamais exposée au navigateur.
//
// Body attendu : { ressource, action, id?, payload? }
// Combinaisons autorisées, volontairement en liste blanche stricte :
//   products     : insert | update | delete
//   bannieres    : insert | update | delete
//   avis         : update (uniquement le champ "valide") | delete
//   reservations : update (uniquement le champ "statut")
//   utilisateurs : list   (lecture seule, pour le tableau de bord admin)
//                  delete (profil Supabase + compte de connexion Firebase)
//   codes_promo  : list | insert | update | delete
//   visiteurs    : list     (résumé de toutes les sessions, pour le tableau de bord)
//                  timeline (chronologie détaillée d'une session précise)
//   parametres   : list | upsert (adresse/tél agence, images de catégories — lecture publique conservée)
//   retours      : list | update (uniquement le champ "statut") — la création (client) passe par api/facture.js
//   offres_groupees : list | insert | update | delete (Flash Combo — insert/update prennent aussi le tableau des accessoires éligibles)

const { createClient } = require('@supabase/supabase-js');
const { verifierRequeteAdmin } = require('./_lib/adminSession');
const { envoyerPushUtilisateur } = require('./_lib/envoyerPush');

const TABLE_REELLE = { bannieres: 'bannières' }; // nom réel de la table en base

module.exports = async (req, res) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    res.setHeader('Content-Type', 'application/json');
    if (req.method === 'OPTIONS') return res.status(200).end();
    if (req.method !== 'POST') return res.status(405).json({ error: 'Méthode non autorisée' });

    const session = verifierRequeteAdmin(req, process.env.ADMIN_SESSION_SECRET);
    if (!session) return res.status(401).json({ error: 'Accès réservé à l\'administrateur' });

    const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

    try {
        const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
        const { ressource, action, id, payload } = body || {};
        const table = TABLE_REELLE[ressource] || ressource;

        // utilisateurs : lecture seule, pour le tableau de bord admin
        if (ressource === 'utilisateurs' && action === 'list') {
            const { data, error } = await supabase
                .from('utilisateurs')
                .select('id,nom,email,telephone,points,created_at,firebase_uid,politique_acceptee_le')
                .order('created_at', { ascending: false });
            if (error) throw error;
            return res.status(200).json({ data });
        }

        // feedback_produits : lecture seule agrégée, pour le tableau de bord
        // admin (module de personnalisation en fiche produit).
        if (ressource === 'feedback_produits' && action === 'stats') {
            const { data, error } = await supabase
                .from('feedback_produits')
                .select('choix, categorie, produit_nom, created_at')
                .order('created_at', { ascending: false })
                .limit(2000);
            if (error) throw error;

            const parChoix = {};
            const parProduit = {};
            for (const r of data) {
                parChoix[r.choix] = (parChoix[r.choix] || 0) + 1;
                if (r.produit_nom) {
                    const cle = `${r.produit_nom}|${r.choix}`;
                    parProduit[cle] = (parProduit[cle] || 0) + 1;
                }
            }
            return res.status(200).json({ total: data.length, parChoix, parProduit, recents: data.slice(0, 30) });
        }

        if (ressource === 'products' && action === 'insert') {
            const { data, error } = await supabase.from('products').insert([payload]).select().single();
            if (error) throw error;
            return res.status(200).json({ data });
        }
        if (ressource === 'products' && action === 'update') {
            if (!id) return res.status(400).json({ error: 'id manquant' });
            const { data, error } = await supabase.from('products').update(payload).eq('id', id).select().single();
            if (error) throw error;
            return res.status(200).json({ data });
        }
        if (ressource === 'products' && action === 'delete') {
            if (!id) return res.status(400).json({ error: 'id manquant' });
            const { error } = await supabase.from('products').delete().eq('id', id);
            if (error) throw error;
            return res.status(200).json({ ok: true });
        }

        if (ressource === 'bannieres' && action === 'insert') {
            const { data, error } = await supabase.from(table).insert([payload]).select().single();
            if (error) throw error;
            return res.status(200).json({ data });
        }
        if (ressource === 'bannieres' && action === 'update') {
            if (!id) return res.status(400).json({ error: 'id manquant' });
            const { data, error } = await supabase.from(table).update(payload).eq('id', id).select().single();
            if (error) throw error;
            return res.status(200).json({ data });
        }
        if (ressource === 'bannieres' && action === 'delete') {
            if (!id) return res.status(400).json({ error: 'id manquant' });
            const { error } = await supabase.from(table).delete().eq('id', id);
            if (error) throw error;
            return res.status(200).json({ ok: true });
        }

        if (ressource === 'avis' && action === 'update') {
            if (!id) return res.status(400).json({ error: 'id manquant' });
            // Liste blanche stricte : seul le champ "valide" est modifiable ici.
            const { data, error } = await supabase.from('avis').update({ valide: !!payload?.valide }).eq('id', id).select().single();
            if (error) throw error;
            return res.status(200).json({ data });
        }
        if (ressource === 'avis' && action === 'delete') {
            if (!id) return res.status(400).json({ error: 'id manquant' });
            const { error } = await supabase.from('avis').delete().eq('id', id);
            if (error) throw error;
            return res.status(200).json({ ok: true });
        }

        if (ressource === 'reservations' && action === 'update') {
            if (!id) return res.status(400).json({ error: 'id manquant' });
            // Liste blanche stricte : seul le statut est modifiable ici.
            const { data, error } = await supabase.from('reservations').update({ statut: payload?.statut }).eq('id', id).select().single();
            if (error) throw error;
            if (data?.utilisateur_id && data?.statut) {
                const messages = {
                    'en attente': { titre: '⏳ Commande en préparation', corps: `Ta commande ${data.code} est en préparation.` },
                    'livre': { titre: '🚚 Commande livrée !', corps: `Ta commande ${data.code} a été livrée. Merci pour ta confiance !` },
                    'annule': { titre: '❌ Commande annulée', corps: `Ta commande ${data.code} a été annulée.` }
                };
                const msg = messages[data.statut];
                if (msg) {
                    try { await envoyerPushUtilisateur(supabase, data.utilisateur_id, { ...msg, url: '/' }); }
                    catch (e) { console.error('Erreur push statut:', e.message); }
                }
            }
            return res.status(200).json({ data });
        }

        if (ressource === 'utilisateurs' && action === 'delete') {
            if (!id) return res.status(400).json({ error: 'id manquant' });
            const { data: profil, error: errLecture } = await supabase.from('utilisateurs').select('firebase_uid,email').eq('id', id).single();
            if (errLecture || !profil) return res.status(404).json({ error: 'Client introuvable' });

            // On détache (jamais supprime) l'historique de commandes du
            // client — l'historique/comptabilité reste, seul le lien vers
            // le compte disparaît.
            await supabase.from('reservations').update({ utilisateur_id: null }).eq('utilisateur_id', id);
            // Nettoyage best-effort des favoris s'ils existent (table optionnelle).
            try { await supabase.from('favoris').delete().eq('utilisateur_id', id); } catch (_) {}

            const { error: errSuppr } = await supabase.from('utilisateurs').delete().eq('id', id);
            if (errSuppr) throw errSuppr;
            // Le compte de connexion Firebase n'est PAS supprimé ici (clé de
            // service bloquée par la politique Google) — on renvoie ses
            // coordonnées pour une suppression manuelle en 1 clic dans la
            // console Firebase (Authentication → Users).
            return res.status(200).json({ ok: true, firebase_uid: profil.firebase_uid, email: profil.email });
        }

        if (ressource === 'codes_promo' && action === 'list') {
            const { data, error } = await supabase.from('codes_promo').select('*').order('created_at', { ascending: false });
            if (error) throw error;
            return res.status(200).json({ data });
        }
        if (ressource === 'codes_promo' && action === 'insert') {
            const p = payload || {};
            if (!p.code || !p.type || !p.valeur) return res.status(400).json({ error: 'Code, type et valeur requis' });
            const { data, error } = await supabase.from('codes_promo').insert([{
                code: String(p.code).trim().toUpperCase(),
                type: p.type === 'montant' ? 'montant' : 'pourcentage',
                valeur: Math.abs(parseFloat(p.valeur)) || 0,
                actif: p.actif !== false,
                date_expiration: p.date_expiration || null,
                usage_max: p.usage_max ? parseInt(p.usage_max, 10) : null,
                montant_min: p.montant_min ? parseFloat(p.montant_min) : null
            }]).select().single();
            if (error) {
                if (error.code === '23505') return res.status(400).json({ error: 'Ce code existe déjà' });
                throw error;
            }
            return res.status(200).json({ data });
        }
        if (ressource === 'codes_promo' && action === 'update') {
            if (!id) return res.status(400).json({ error: 'id manquant' });
            // Liste blanche stricte des champs modifiables.
            const p = payload || {};
            const maj = {};
            if ('actif' in p) maj.actif = !!p.actif;
            if ('valeur' in p) maj.valeur = Math.abs(parseFloat(p.valeur)) || 0;
            if ('usage_max' in p) maj.usage_max = p.usage_max ? parseInt(p.usage_max, 10) : null;
            if ('date_expiration' in p) maj.date_expiration = p.date_expiration || null;
            if ('montant_min' in p) maj.montant_min = p.montant_min ? parseFloat(p.montant_min) : null;
            const { data, error } = await supabase.from('codes_promo').update(maj).eq('id', id).select().single();
            if (error) throw error;
            return res.status(200).json({ data });
        }
        if (ressource === 'codes_promo' && action === 'delete') {
            if (!id) return res.status(400).json({ error: 'id manquant' });
            const { error } = await supabase.from('codes_promo').delete().eq('id', id);
            if (error) throw error;
            return res.status(200).json({ ok: true });
        }

        if (ressource === 'visiteurs' && action === 'list') {
            const { data: sessions, error: errSessions } = await supabase
                .from('visiteurs_sessions').select('*, utilisateurs(nom, telephone)')
                .order('derniere_activite', { ascending: false }).limit(200);
            if (errSessions) throw errSessions;

            const ids = (sessions || []).map(s => s.session_id);
            const { data: compteurs, error: errCompteurs } = await supabase
                .from('visiteurs_evenements').select('session_id, type').in('session_id', ids);
            if (errCompteurs) throw errCompteurs;

            const parSession = {};
            (compteurs || []).forEach(e => {
                if (!parSession[e.session_id]) parSession[e.session_id] = { total: 0, pages: 0, produits: 0, paniers: 0 };
                parSession[e.session_id].total++;
                if (e.type === 'page_view') parSession[e.session_id].pages++;
                if (e.type === 'produit_vu' || e.type === 'produit_impression') parSession[e.session_id].produits++;
                if (e.type === 'panier_ajout') parSession[e.session_id].paniers++;
            });

            const data = (sessions || []).map(s => ({
                ...s,
                stats: parSession[s.session_id] || { total: 0, pages: 0, produits: 0, paniers: 0 }
            }));
            return res.status(200).json({ data });
        }
        if (ressource === 'visiteurs' && action === 'timeline') {
            const sessionId = (payload && payload.session_id) || id;
            if (!sessionId) return res.status(400).json({ error: 'session_id manquant' });
            const { data, error } = await supabase
                .from('visiteurs_evenements').select('*').eq('session_id', sessionId)
                .order('created_at', { ascending: false }).limit(500);
            if (error) throw error;
            return res.status(200).json({ data });
        }

        if (ressource === 'parametres' && action === 'list') {
            const { data, error } = await supabase.from('parametres').select('*');
            if (error) throw error;
            return res.status(200).json({ data });
        }
        if (ressource === 'parametres' && action === 'upsert') {
            const rows = Array.isArray(payload) ? payload : [];
            if (!rows.length) return res.status(400).json({ error: 'Aucune donnée à enregistrer' });
            // Liste blanche stricte des lignes acceptées (cle + valeur uniquement).
            const propres = rows
                .filter(r => r && typeof r.cle === 'string')
                .map(r => ({ cle: r.cle, valeur: r.valeur != null ? String(r.valeur) : null }));
            const { error } = await supabase.from('parametres').upsert(propres, { onConflict: 'cle' });
            if (error) throw error;
            return res.status(200).json({ ok: true });
        }

        if (ressource === 'reservations' && action === 'list') {
            const { data, error } = await supabase.from('reservations').select('*').order('created_at', { ascending: false });
            if (error) throw error;
            return res.status(200).json({ data });
        }

        if (ressource === 'retours' && action === 'list') {
            const { data, error } = await supabase.from('retours').select('*').order('created_at', { ascending: false });
            if (error) throw error;
            return res.status(200).json({ data });
        }
        if (ressource === 'retours' && action === 'update') {
            if (!id) return res.status(400).json({ error: 'id manquant' });
            // Liste blanche stricte : seul le statut est modifiable ici.
            const { data, error } = await supabase.from('retours').update({ statut: payload?.statut }).eq('id', id).select().single();
            if (error) throw error;
            return res.status(200).json({ data });
        }

        if (ressource === 'offres_groupees' && action === 'list') {
            const { data: offres, error: errOffres } = await supabase
                .from('offres_groupees').select('*, products:produit_principal_id(id,name,image_url,resale_price)')
                .order('created_at', { ascending: false });
            if (errOffres) throw errOffres;
            const { data: choix, error: errChoix } = await supabase
                .from('offres_groupees_choix').select('offre_id, produit_id, products(id,name,image_url,resale_price,quantity)');
            if (errChoix) throw errChoix;
            const data = (offres || []).map(o => ({
                ...o,
                choix: (choix || []).filter(c => c.offre_id === o.id).map(c => c.products)
            }));
            return res.status(200).json({ data });
        }
        if (ressource === 'offres_groupees' && action === 'insert') {
            const p = payload || {};
            if (!p.produit_principal_id || !p.prix_ensemble || !Array.isArray(p.choix_ids) || p.choix_ids.length < 2) {
                return res.status(400).json({ error: 'Produit principal, prix, et au moins 2 accessoires éligibles requis' });
            }
            const { data: offre, error: errInsert } = await supabase.from('offres_groupees').insert([{
                nom: p.nom || 'Flash Combo',
                description: p.description || null,
                produit_principal_id: p.produit_principal_id,
                prix_ensemble: Math.abs(parseFloat(p.prix_ensemble)) || 0,
                nb_choix_requis: Math.max(1, parseInt(p.nb_choix_requis, 10) || 2),
                actif: p.actif !== false,
                date_debut: p.date_debut || null,
                date_fin: p.date_fin || null
            }]).select().single();
            if (errInsert) throw errInsert;
            const lignes = [...new Set(p.choix_ids)].map(pid => ({ offre_id: offre.id, produit_id: pid }));
            const { error: errChoix } = await supabase.from('offres_groupees_choix').insert(lignes);
            if (errChoix) throw errChoix;
            return res.status(200).json({ data: offre });
        }
        if (ressource === 'offres_groupees' && action === 'update') {
            if (!id) return res.status(400).json({ error: 'id manquant' });
            const p = payload || {};
            const maj = {};
            if ('actif' in p) maj.actif = !!p.actif;
            if ('prix_ensemble' in p) maj.prix_ensemble = Math.abs(parseFloat(p.prix_ensemble)) || 0;
            if ('date_debut' in p) maj.date_debut = p.date_debut || null;
            if ('date_fin' in p) maj.date_fin = p.date_fin || null;
            if (Object.keys(maj).length) {
                const { error } = await supabase.from('offres_groupees').update(maj).eq('id', id);
                if (error) throw error;
            }
            if (Array.isArray(p.choix_ids)) {
                // Remplace entièrement la liste des accessoires éligibles.
                await supabase.from('offres_groupees_choix').delete().eq('offre_id', id);
                const lignes = [...new Set(p.choix_ids)].map(pid => ({ offre_id: id, produit_id: pid }));
                if (lignes.length) {
                    const { error: errChoix } = await supabase.from('offres_groupees_choix').insert(lignes);
                    if (errChoix) throw errChoix;
                }
            }
            return res.status(200).json({ ok: true });
        }
        if (ressource === 'offres_groupees' && action === 'delete') {
            if (!id) return res.status(400).json({ error: 'id manquant' });
            const { error } = await supabase.from('offres_groupees').delete().eq('id', id);
            if (error) throw error;
            return res.status(200).json({ ok: true });
        }

        return res.status(400).json({ error: 'Combinaison ressource/action non autorisée' });
    } catch (e) {
        console.error('Erreur admin-action:', e);
        return res.status(500).json({ error: 'Erreur serveur' });
    }
};
